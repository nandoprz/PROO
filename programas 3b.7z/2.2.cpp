#include <iostream>
int main() {  // Se a�adi� {
    int arreglo[] = {1, 2, 3, 4, 5};
    int *ptrArreglo = arreglo;  // Se cambi� " por *

    std::cout << "Primer elemento: " << *ptrArreglo << std::endl; // Se a�adi� *
    std::cout << "Segundo elemento: " << *(ptrArreglo + 1) << std::endl; // Se corrigi�
    std::cout << "Tercer elemento: " << *(ptrArreglo + 2) << std::endl;

    // Iteraci�n sencilla:
    for (int i = 0; i < 5; ++i) {
        std::cout << "Elemento " << i << ": " << *(ptrArreglo + i) << std::endl; // Se corrigi�
    }
    return 0;
}
