#include <iostream>
void incrementar(int *valor) {
    (*valor)++;  // Se quit� un + de m�s
}

int main() {
    int num = 10;
    std::cout << "Valor antes: " << num << std::endl;  // Texto simplificado
    incrementar(&num);
    std::cout << "Valor despu�s: " << num << std::endl;  // Texto simplificado
    return 0;
}

