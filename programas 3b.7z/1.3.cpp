#include <iostream>
int main() { // 'main' con 'm' min�scula
    int *ptr = NULL; // Usar NULL si el compilador no soporta C++11
    if (ptr == NULL) {
        std::cout << "El puntero es nulo." << std::endl;
    } else {
        std::cout << "El valor apuntado por el puntero es: " << *ptr << std::endl;
    }
    return 0;
}
